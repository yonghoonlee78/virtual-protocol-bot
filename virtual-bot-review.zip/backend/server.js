require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const http = require('http');
const socketIO = require('socket.io');

// Models
const Agent = require('./src/models/Agent');
const User = require('./src/models/User');

// Services
const BaseProvider = require('./src/services/blockchain/baseProvider');
const VirtualProtocolService = require('./src/services/blockchain/virtualProtocol');
const AgentSyncService = require('./src/services/blockchain/agentSync');
const PriceService = require('./src/services/priceService');
const AlertService = require('./src/services/alertService');

const app = express();
const server = http.createServer(app);
const io = socketIO(server, {
  cors: {
    origin: "http://localhost:3001",
    methods: ["GET", "POST"]
  }
});

// Global variables
let botInstance = null;
let priceUpdateInterval = null;
let alertCheckInterval = null;

// Middleware
app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

// Health check
app.get('/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV,
    mongodb: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected'
  });
});

// API info
app.get('/api', (req, res) => {
  res.json({ 
    message: 'Virtual Protocol Trading Bot API',
    version: '1.0.0'
  });
});

// Get all agents
app.get('/api/agents', async (req, res) => {
  try {
    const agents = await Agent.find({ symbol: { $ne: 'TEST' } })
      .sort({ 'priceData.current': -1 });
    res.json(agents);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Blockchain status
app.get('/api/blockchain/status', async (req, res) => {
  try {
    const provider = new BaseProvider();
    const blockNumber = await provider.getBlockNumber();
    res.json({
      chain: 'Base',
      chainId: 8453,
      blockNumber
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// WebSocket
io.on('connection', (socket) => {
  console.log('👤 Client connected');
  
  socket.on('error', (error) => {
    console.error('Socket error:', error);
  });
  
  Agent.find({ symbol: { $ne: 'TEST' } })
    .then(agents => {
      socket.emit('agents', agents);
    })
    .catch(error => {
      console.error('Error fetching agents:', error);
    });
  
  socket.on('disconnect', () => {
    console.log('👤 Client disconnected');
  });
});

// MongoDB & Services initialization
async function initializeServices() {
  if (!process.env.MONGODB_URI) {
    console.log('⚠️ MongoDB URI not configured');
    return;
  }

  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('✅ MongoDB connected');
    
    // Blockchain sync
    try {
      const syncService = new AgentSyncService();
      await syncService.syncAgentsFromBlockchain();
      console.log('✅ Blockchain sync complete');
    } catch (error) {
      console.error('❌ Blockchain sync error:', error.message);
    }
    
    // Price service
    try {
      const priceService = new PriceService(io);
      await priceService.updateAllPrices();
      
      priceUpdateInterval = setInterval(() => {
        priceService.updateAllPrices();
      }, 30 * 60 * 1000); // 30 minutes
      
      console.log('✅ Price service started');
    } catch (error) {
      console.error('❌ Price service error:', error.message);
    }
    
    // Telegram bot
    if (process.env.BOT_TOKEN && process.env.BOT_TOKEN !== 'your_telegram_bot_token') {
      try {
        const TelegramBot = require('./src/bot/telegramBot');
        botInstance = new TelegramBot(process.env.BOT_TOKEN);
        botInstance.launch();
        global.bot = botInstance.bot;
        console.log('✅ Telegram bot started');
        
        // Alert service
        setTimeout(() => {
          if (botInstance && botInstance.bot) {
            const alertService = new AlertService(botInstance.bot);
            
            alertCheckInterval = setInterval(() => {
              alertService.checkAlerts();
            }, 60 * 1000); // 1 minute
            
            console.log('📢 Alert service started');
          }
        }, 2000);
        
      } catch (error) {
        console.error('❌ Bot error:', error.message);
      }
    } else {
      console.log('⚠️ Telegram bot token not configured');
    }
    
  } catch (error) {
    console.error('❌ MongoDB connection error:', error);
    process.exit(1);
  }
}

// Error handling
app.use((err, req, res, next) => {
  console.error('Error:', err.stack);
  res.status(500).json({ 
    error: 'Something went wrong!',
    message: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// Start server
const PORT = process.env.PORT || 3000;
server.listen(PORT, async () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`📍 Environment: ${process.env.NODE_ENV || 'development'}`);
  
  // Initialize services after server starts
  await initializeServices();
});

// Graceful shutdown
function gracefulShutdown(signal) {
  console.log(`\n${signal} received. Shutting down...`);
  
  if (priceUpdateInterval) clearInterval(priceUpdateInterval);
  if (alertCheckInterval) clearInterval(alertCheckInterval);
  
  if (botInstance) {
    botInstance.stop();
  }
  
  server.close(() => {
    mongoose.connection.close(false, () => {
      console.log('✅ Shutdown complete');
      process.exit(0);
    });
  });
}

process.once('SIGINT', () => gracefulShutdown('SIGINT'));
process.once('SIGTERM', () => gracefulShutdown('SIGTERM'));

module.exports = { app, server, io };