// backend/src/services/walletService.js 생성
const { ethers } = require('ethers');
const crypto = require('crypto');

class WalletService {
  // AES 암호화 (봇 서버에서만 복호화 가능)
  encrypt(text, secret) {
    const algorithm = 'aes-256-cbc';
    const key = crypto.scryptSync(secret, 'salt', 32);
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv(algorithm, key, iv);
    
    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    
    return iv.toString('hex') + ':' + encrypted;
  }

  decrypt(text, secret) {
    const algorithm = 'aes-256-cbc';
    const key = crypto.scryptSync(secret, 'salt', 32);
    const parts = text.split(':');
    const iv = Buffer.from(parts.shift(), 'hex');
    const encrypted = Buffer.from(parts.join(':'), 'hex');
    const decipher = crypto.createDecipheriv(algorithm, key, iv);
    
    let decrypted = decipher.update(encrypted, null, 'utf8');
    decrypted += decipher.final('utf8');
    
    return decrypted;
  }

  // 사용자별 지갑 생성
  async createWallet(userId) {
    // 새 지갑 생성
    const wallet = ethers.Wallet.createRandom();
    
    // 프라이빗 키 암호화 (환경변수의 시크릿 키 사용)
    const encryptedKey = this.encrypt(
      wallet.privateKey, 
      process.env.WALLET_SECRET || 'your-secret-key'
    );
    
    return {
      address: wallet.address,
      encryptedPrivateKey: encryptedKey
    };
  }

  // 지갑 복구 (사용자 요청 시)
  async getPrivateKey(encryptedKey) {
    return this.decrypt(
      encryptedKey, 
      process.env.WALLET_SECRET || 'your-secret-key'
    );
  }
}

module.exports = WalletService;