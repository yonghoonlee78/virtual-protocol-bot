// backend/src/bot/telegramBot.js
const { Telegraf } = require('telegraf');
const { ethers } = require('ethers');
const User = require('../models/User');
const Agent = require('../models/Agent');
const Portfolio = require('../models/Portfolio');
const PriceAlert = require('../models/PriceAlert');
const Trade = require('../models/Trade');
const WalletService = require('../services/walletService');

class TelegramBot {
  constructor(token) {
    this.bot = new Telegraf(token);
    this.walletService = new WalletService();
    this.setupCommands();
    this.setupActions();
  }

  setupCommands() {
    // /start - BONKbot style with auto wallet creation
    this.bot.start(async (ctx) => {
      const user = await this.getOrCreateUser(ctx);
      
      // Auto create wallet if doesn't exist
      if (!user.wallet || !user.wallet.address) {
        const wallet = await this.walletService.createWallet(user._id);
        user.wallet = {
          address: wallet.address,
          encryptedPrivateKey: wallet.encryptedPrivateKey,
          createdAt: new Date(),
          balance: {
            eth: 0,
            usdt: 0,
            virtual: 0
          }
        };
        await user.save();
      }
      
      // BONKbot style welcome message
      const message = 
        `<b>Welcome to VAIBOT</b>\n` +
        `Base chain's fastest bot to trade any Virtual Protocol token!\n\n` +
        
        `You currently have no USDT in your wallet. To start trading, deposit USDT to your VAIBOT wallet address:\n\n` +
        
        `<code>${user.wallet.address}</code> (tap to copy)\n\n` +
        
        `Once done, tap refresh and your balance will appear here.\n\n` +
        
        `To buy a token enter a ticker, token address, or a URL from <a href="https://app.virtuals.io">app.virtuals.io</a>, Dexscreener or Base scan.\n\n` +
        
        `For more info on your wallet and to retrieve your private key, tap the wallet button below. ` +
        `User funds are safe on VAIBOT, but if you expose your private key we can't protect you!`;
      
      await ctx.replyWithHTML(message, {
        reply_markup: {
          inline_keyboard: [
            [
              { text: 'Buy', callback_data: 'menu_buy' },
              { text: 'Sell & Manage', callback_data: 'menu_sell' }
            ],
            [
              { text: 'Help', callback_data: 'help' },
              { text: 'Refer Friends', callback_data: 'refer' },
              { text: 'Alerts', callback_data: 'alerts' }
            ],
            [
              { text: 'Wallet', callback_data: 'wallet' },
              { text: 'Refresh', callback_data: 'refresh' }
            ],
            [
              { text: 'Limit Orders', callback_data: 'limit_orders' },
              { text: 'Withdraw', callback_data: 'withdraw' }
            ],
            [
              { text: 'Import wallet', callback_data: 'import_wallet' }
            ]
          ]
        }
      });
    });

    // /help
    this.bot.help(async (ctx) => {
      await ctx.replyWithHTML(
        `<b>VAIBOT Help</b>\n\n` +
        `Trade Virtual Protocol tokens on Base chain.\n\n` +
        `• Tap buttons to navigate\n` +
        `• Auto wallet generation\n` +
        `• Trade with USDT\n` +
        `• Real-time prices from app.virtuals.io\n\n` +
        `/start - Main menu\n` +
        `/help - This message`
      );
    });
  }

  setupActions() {
    // Buy Menu
    this.bot.action('menu_buy', async (ctx) => {
      await ctx.answerCbQuery();
      
      const topTokens = await Agent.find()
        .sort({ 'tradingStats.marketCap': -1 })
        .limit(5);
      
      let message = `<b>BUY TOKENS</b>\n\n`;
      message += `Top Virtual Protocol Tokens:\n━━━━━━━━━━━━━━━━━\n\n`;
      
      const buttons = [];
      
      for (const token of topTokens) {
        const mcap = (token.tradingStats?.marketCap || 0) / 1000000;
        message += `<b>${token.symbol}</b>\n`;
        message += `Price: $${token.priceData.current.toFixed(6)}\n`;
        message += `MCap: $${mcap.toFixed(2)}M\n\n`;
        
        buttons.push([{
          text: `Buy ${token.symbol}`,
          callback_data: `select_buy_${token.symbol}`
        }]);
      }
      
      buttons.push([{ 
        text: 'Enter Contract Address', 
        callback_data: 'buy_custom_ca' 
      }]);
      buttons.push([{ 
        text: '« Back to Main', 
        callback_data: 'back_main' 
      }]);
      
      await ctx.editMessageText(message, {
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: buttons }
      });
    });

    // Select token to buy - USDT version
    this.bot.action(/select_buy_(.+)/, async (ctx) => {
      const symbol = ctx.match[1];
      await ctx.answerCbQuery();
      
      const token = await Agent.findOne({ symbol });
      if (!token) return;
      
      const message = 
        `<b>BUY ${symbol}</b>\n\n` +
        `Price: $${token.priceData.current.toFixed(6)}\n` +
        `24h Change: ${token.priceData.change24h >= 0 ? '+' : ''}${token.priceData.change24h.toFixed(2)}%\n` +
        `MCap: $${(token.tradingStats.marketCap/1000000).toFixed(2)}M\n` +
        `Volume: $${(token.tradingStats.volume24h/1000).toFixed(2)}K\n\n` +
        `Select amount in USDT:`;
      
      await ctx.editMessageText(message, {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '10 USDT', callback_data: `buy_${symbol}_10` },
              { text: '50 USDT', callback_data: `buy_${symbol}_50` },
              { text: '100 USDT', callback_data: `buy_${symbol}_100` }
            ],
            [
              { text: '250 USDT', callback_data: `buy_${symbol}_250` },
              { text: '500 USDT', callback_data: `buy_${symbol}_500` },
              { text: '1000 USDT', callback_data: `buy_${symbol}_1000` }
            ],
            [
              { text: 'Custom Amount', callback_data: `buy_custom_${symbol}` }
            ],
            [
              { text: 'Slippage: 10%', callback_data: 'buy_settings' }
            ],
            [
              { text: '« Back', callback_data: 'menu_buy' }
            ]
          ]
        }
      });
    });

    this.bot.action(/buy_([^_]+)_([0-9.]+)/, async (ctx) => {
      const symbol = ctx.match[1];
      const usdtAmount = parseFloat(ctx.match[2]);
      await ctx.answerCbQuery();
      
      const user = await this.getUser(ctx);
      
      // 잔액 확인 로직 추가
      const userBalance = user.wallet?.balance?.usdt || 0;
      const gasRequired = 0.5; // 가스비 예상치 (USDT)
      const totalRequired = usdtAmount + gasRequired;
      
      // 잔액 부족 체크
      if (userBalance < totalRequired) {
        await ctx.editMessageText(
          `Balance: ${userBalance} USDT ($${userBalance.toFixed(2)})\n\n` +
          `🔴 Insufficient balance for buy amount + gas\n\n` +
          `You need ${totalRequired} USDT to complete this transaction.\n` +
          `(${usdtAmount} USDT for purchase + ${gasRequired} USDT for gas)\n\n` +
          `Please deposit USDT to your wallet:\n` +
          `<code>${user.wallet.address}</code>`,
          {
            parse_mode: 'HTML',
            reply_markup: {
              inline_keyboard: [
                [{ text: 'Refresh Balance', callback_data: 'refresh' }],
                [{ text: 'Wallet Info', callback_data: 'wallet' }],
                [{ text: '« Back', callback_data: 'menu_buy' }]
              ]
            }
          }
        );
        return; // 거래 중단
      }
      
      const agent = await Agent.findOne({ symbol });

      // Portfolio update
      let portfolio = await Portfolio.findOne({ userId: user._id });
      if (!portfolio) {
        portfolio = new Portfolio({ userId: user._id, holdings: [] });
      }
      
      const price = agent.priceData.current;
      const tokenAmount = usdtAmount / price;
      
      const existingIndex = portfolio.holdings.findIndex(h => h.symbol === symbol);
      
      if (existingIndex >= 0) {
        const existing = portfolio.holdings[existingIndex];
        const totalCost = (existing.amount * existing.averagePrice) + (tokenAmount * price);
        const totalAmount = existing.amount + tokenAmount;
        
        portfolio.holdings[existingIndex].amount = totalAmount;
        portfolio.holdings[existingIndex].averagePrice = totalCost / totalAmount;
      } else {
        portfolio.holdings.push({
          agentAddress: agent.address,
          symbol: symbol,
          amount: tokenAmount,
          averagePrice: price
        });
      }
      
      await portfolio.save();

        // 잔액 차감
  user.wallet.balance.usdt -= totalRequired;
  await user.save();
      
      // Trade record
      await Trade.create({
        userId: user._id,
        type: 'buy',
        symbol,
        amount: tokenAmount,
        price,
        totalValue: usdtAmount
      });
      
      const message = 
      `<b>BUY ORDER EXECUTED</b>\n\n` +
      `Bought ${tokenAmount.toFixed(2)} ${symbol}\n` +
      `Price: $${price.toFixed(6)}\n` +
      `Total: ${usdtAmount} USDT\n\n` +
      `TX: Processing on Base...\n\n` +
      `New Balance: ${user.wallet.balance.usdt.toFixed(2)} USDT`;
  
      
      await ctx.editMessageText(message, {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: 'View Portfolio', callback_data: 'menu_portfolio' }],
            [{ text: 'Buy More', callback_data: 'menu_buy' }],
            [{ text: '« Main Menu', callback_data: 'back_main' }]
          ]
        }
      });
    });

    // Wallet - Show private key
    this.bot.action('wallet', async (ctx) => {
      await ctx.answerCbQuery();
      const user = await this.getUser(ctx);
      
      // 지갑이 없으면 생성
      if (!user.wallet || !user.wallet.address) {
        const wallet = await this.walletService.createWallet(user._id);
        user.wallet = {
          address: wallet.address,
          encryptedPrivateKey: wallet.encryptedPrivateKey,
          createdAt: new Date(),
          balance: {
            eth: 0,
            usdt: 0,
            virtual: 0
          }
        };
        await user.save();
      }
      
      await ctx.editMessageText(
        `<b>YOUR VAIBOT WALLET</b>\n\n` +
        `Address: <code>${user.wallet.address}</code>\n` +
        `Chain: Base\n` +
        `Balance: ${user.wallet.balance?.usdt || 0} USDT\n\n` +
        `⚠️ <b>Warning:</b> Your private key controls this wallet. Never share it!\n\n` +
        `Tap below to reveal your private key:`,
        {
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [{ text: 'Show Private Key', callback_data: 'show_private_key' }],
              [{ text: 'Export Wallet', callback_data: 'export_wallet' }],
              [{ text: '« Back', callback_data: 'back_main' }]
            ]
          }
        }
      );
    });

    // Show private key
    this.bot.action('show_private_key', async (ctx) => {
      await ctx.answerCbQuery();
      const user = await this.getUser(ctx);
      
      // Decrypt private key
      const privateKey = await this.walletService.getPrivateKey(
        user.wallet.encryptedPrivateKey
      );
      
      // Auto-delete message
      const msg = await ctx.reply(
        `🔐 <b>PRIVATE KEY</b>\n\n` +
        `<code>${privateKey}</code>\n\n` +
        `⚠️ This message will auto-delete in 30 seconds for security.`,
        { parse_mode: 'HTML' }
      );
      
      setTimeout(() => {
        ctx.deleteMessage(msg.message_id);
      }, 30000);
    });

    // Refresh balance
    this.bot.action('refresh', async (ctx) => {
      await ctx.answerCbQuery('Refreshing balance...');
      const user = await this.getUser(ctx);

      try {
        // Check USDT balance on Base
        const provider = new ethers.JsonRpcProvider(process.env.BASE_RPC_URL);
        const usdtContract = new ethers.Contract(
          '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913', // USDT on Base
          ['function balanceOf(address) view returns (uint256)'],
          provider
        );
      
      
        const balance = await usdtContract.balanceOf(user.wallet.address);
        user.wallet.balance.usdt = parseFloat(ethers.formatUnits(balance, 6));
        await user.save();

            // BONKbot 스타일 잔액 표시
    await ctx.editMessageText(
      `Balance: ${user.wallet.balance.usdt} USDT ($${user.wallet.balance.usdt.toFixed(2)})\n\n` +
      (user.wallet.balance.usdt === 0 ? 
        `Tap to copy the address and send USDT to deposit.\n\n` +
        `You need to deposit USDT on your wallet for this function to work\n` +
        `<code>${user.wallet.address}</code> (tap to copy)` :
        `Your wallet is ready for trading!`),
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: 'Buy', callback_data: 'menu_buy' },
              { text: 'Sell & Manage', callback_data: 'menu_sell' }
            ],
            [
              { text: 'Help', callback_data: 'help' },
              { text: 'Refer Friends', callback_data: 'refer' },
              { text: 'Alerts', callback_data: 'alerts' }
            ],
            [
              { text: 'Wallet', callback_data: 'wallet' },
              { text: 'Refresh', callback_data: 'refresh' }
            ],
            [
              { text: 'Portfolio', callback_data: 'menu_portfolio' },
              { text: 'Withdraw', callback_data: 'withdraw' }
            ]
          ]
        }
      }
    );
  } catch (error) {
    await ctx.reply('Error checking balance. Please try again.');
  }
       
    });

    // Portfolio
    this.bot.action('menu_portfolio', async (ctx) => {
      await ctx.answerCbQuery();
      const user = await this.getUser(ctx);
      const portfolio = await Portfolio.findOne({ userId: user._id });
      
      if (!portfolio || portfolio.holdings.length === 0) {
        await ctx.editMessageText(
          `<b>PORTFOLIO</b>\n\n` +
          `No holdings yet.\n` +
          `Start trading to build your portfolio!`,
          {
            parse_mode: 'HTML',
            reply_markup: {
              inline_keyboard: [
                [{ text: '💰 Buy Tokens', callback_data: 'menu_buy' }],
                [{ text: '« Back', callback_data: 'back_main' }]
              ]
            }
          }
        );
        return;
      }
      
      const stats = await portfolio.calculateValue();
      
      let message = `<b>PORTFOLIO</b>\n━━━━━━━━━━━━━━━━━\n\n`;
      message += `Total Value: $${stats.totalValue.toFixed(2)}\n`;
      message += `Total Cost: $${stats.totalCost.toFixed(2)}\n`;
      message += `P/L: ${stats.profit >= 0 ? '🟢' : '🔴'} $${stats.profit.toFixed(2)} (${stats.profitPercent.toFixed(2)}%)\n\n`;
      message += `<b>Holdings:</b>\n━━━━━━━━━━━━━━━━━\n`;
      
      for (const holding of portfolio.holdings) {
        const agent = await Agent.findOne({ symbol: holding.symbol });
        if (agent) {
          const value = holding.amount * agent.priceData.current;
          const pl = ((agent.priceData.current - holding.averagePrice) / holding.averagePrice * 100);
          
          message += `\n<b>${holding.symbol}</b>\n`;
          message += `Amount: ${holding.amount.toFixed(2)}\n`;
          message += `Value: $${value.toFixed(2)}\n`;
          message += `P/L: ${pl >= 0 ? '+' : ''}${pl.toFixed(2)}%\n`;
        }
      }
      
      await ctx.editMessageText(message, {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '💸 Sell Tokens', callback_data: 'menu_sell' }],
            [{ text: '« Back', callback_data: 'back_main' }]
          ]
        }
      });
    });

    // Back to main
    this.bot.action('back_main', async (ctx) => {
      await ctx.answerCbQuery();
      await this.showMainMenu(ctx, true);
    });

    // Help
    this.bot.action('help', async (ctx) => {
      await ctx.answerCbQuery();
      await ctx.editMessageText(
        `❓ <b>VAIBOT HELP</b>\n\n` +
        `<b>Getting Started:</b>\n` +
        `1. Your wallet is auto-generated on /start\n` +
        `2. Deposit USDT to the wallet address\n` +
        `3. Tap refresh to update balance\n` +
        `4. Start trading!\n\n` +
        `<b>Trading:</b>\n` +
        `• All trades use USDT\n` +
        `• 10% default slippage\n` +
        `• Base chain only\n\n` +
        `<b>Security:</b>\n` +
        `• Private keys are encrypted\n` +
        `• Never share your key\n` +
        `• Export wallet for backup`,
        {
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [[{ text: '« Back', callback_data: 'back_main' }]]
          }
        }
      );
    });
  }

  async showMainMenu(ctx, isEdit = false) {
    const user = await this.getUser(ctx);
    
    // 지갑이 없으면 생성
    if (!user.wallet || !user.wallet.address) {
      const wallet = await this.walletService.createWallet(user._id);
      user.wallet = {
        address: wallet.address,
        encryptedPrivateKey: wallet.encryptedPrivateKey,
        createdAt: new Date(),
        balance: {
          eth: 0,
          usdt: 0,
          virtual: 0
        }
      };
      await user.save();
    }
    
    const message = 
      `<b>VAIBOT</b>\n` +
      `━━━━━━━━━━━━━━━━━\n` +
      `Wallet: <code>${user.wallet.address.slice(0,6)}...${user.wallet.address.slice(-4)}</code>\n` +
      `Balance: ${user.wallet.balance?.usdt || 0} USDT\n` +
      `━━━━━━━━━━━━━━━━━\n\n` +
      `Trade Virtual Protocol tokens on Base`;
    
    const keyboard = {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'Buy', callback_data: 'menu_buy' },
            { text: 'Sell & Manage', callback_data: 'menu_sell' }
          ],
          [
            { text: 'Help', callback_data: 'help' },
            { text: 'Refer', callback_data: 'refer' },
            { text: 'Alerts', callback_data: 'alerts' }
          ],
          [
            { text: 'Wallet', callback_data: 'wallet' },
            { text: 'Refresh', callback_data: 'refresh' }
          ],
          [
            { text: 'Portfolio', callback_data: 'menu_portfolio' },
            { text: 'Withdraw', callback_data: 'withdraw' }
          ]
        ]
      }
    };

    if (isEdit) {
      await ctx.editMessageText(message, { parse_mode: 'HTML', ...keyboard });
    } else {
      await ctx.replyWithHTML(message, keyboard);
    }
  }

  async getOrCreateUser(ctx) {
    const telegramId = ctx.from.id.toString();
    let user = await User.findOne({ telegramId });
    
    if (!user) {
      user = await User.create({
        telegramId,
        profile: {
          firstName: ctx.from.first_name,
          username: ctx.from.username
        }
      });
    }
    
    return user;
  }

  async getUser(ctx) {
    const user = await User.findOne({ telegramId: ctx.from.id.toString() });
    
    // 사용자가 없으면 생성
    if (!user) {
      return await this.getOrCreateUser(ctx);
    }
    
    return user;
  }

  launch() {
    this.bot.launch();
    console.log('VAIBOT started - Virtual Protocol Trading Bot');
  }

  stop() {
    this.bot.stop();
  }
}

module.exports = TelegramBot;